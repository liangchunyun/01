var db=wx.cloud.database()
var app=getApp()
Page({
  data: {
    tj:[],
    _tj:[],
    zuixinorzuire:0,
    yizhou:"",
    kong:false
  }, 
  //点击跳转到详情进行阅读
  tiaozhuan(e){
    //console.log(e.currentTarget.dataset.address)
    var address=e.currentTarget.dataset.address
    var id=e.currentTarget.dataset.id
    var index=e.currentTarget.dataset.index
    // wx.navigateTo({
    //   url: './detail/detail?address='+address,
    // })
    console.log("未知id:",id)
    wx.navigateTo({
      url:"../plate2/plate2?id="+id+"&fenxiang=false&liuyan=true&love="
    })

    //添加浏览数
    // wx.cloud.callFunction({
    //   name:"look",
    //   data:{
    //     id:id,
    //     type:'tj'
    //   }
    // })

  },
  onLoad(e){
    //写出一周前的时间戳
    var now=new Date().getTime()//现在的时间
    var yizhou=(now-3600*7000*24)
    console.log("现在：",now)
    console.log("一周：",yizhou)
    this.setData({
      yizhou:yizhou
    })
    this.jiazai()
  },
  //加载更多
async jiazai(){
    var head=this.data.tj.length
    var zuixinorzuire=this.data.zuixinorzuire
    if(zuixinorzuire==0){
      //按照时间排取消时间限制，
      zuixinorzuire="time"
      var yizhou=0
    }else{
      //按照热度排行
      zuixinorzuire="look"
      var yizhou=this.data.yizhou
    }

    db.collection('tj').where({
      time:db.command.gt(yizhou)
    }).orderBy(zuixinorzuire, 'asc').skip(head).get().then((res)=>{

      console.log("加载一次tj：",res)
      var tj=this.data.tj
      tj.push.apply(tj,res.data)
      console.log("合并一次tj：",tj)
      this.setData({
        tj:tj,
        kong:true
      })
      wx.stopPullDownRefresh({})
      return true
    })
  },
  //页面上拉触底事件的处理函数！！！！！！！！！！！！！！
  onReachBottom: function () {
    this.jiazai()
  },
   //下拉动作-刷新
  onPullDownRefresh: function () {
    this.setData({
      tj:[]
    })
    this.shuaxin1()
  },
  //下拉刷新
async shuaxin1(){
    // wx.showLoading({
    //   title: '正在刷新',
    // })

    var ss = await this.jiazai()
    // wx.hideLoading({})
    wx.showToast({
      title: '刷新成功',
      icon:'none',
      duration:800
    })
  },
  onShow(){
    wx.getSetting({
      success (res) {
        //console.log(res.authSetting)
        console.log(res)
      }
    })
    this.checkred()
  },
  //刷新消息红点(用于更新非tabar页面未设置的红点)
  checkred(){
    var weidu=app.message.length
    if(weidu!=0){
      //有未读
      wx.setTabBarBadge({
        index: 3,
        text: weidu.toString()
      })
    }else{
      wx.removeTabBarBadge({index: 3})
    }
  },
  //返回组件Tabs的监听
  changetitle(e){
    console.log("title:",e.detail)
    var zuixinorzuire=this.data.zuixinorzuire
    if(e.detail!=zuixinorzuire){
      //暂存待机位
      var zhongjian=this.data._tj
      //赋值待机位
      var _tj=this.data.tj
      var tj=zhongjian
      this.setData({
        zuixinorzuire:e.detail,
        tj:tj,
        _tj:_tj
      })
      console.log(tj)
      if(tj.length==0){
        console.log("数组空，加载")
        this.jiazai()
      }
    }
  },
})